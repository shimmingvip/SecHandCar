package com.neusoft.service;


import com.neusoft.model.CarCustomer;

public interface CarCustomerService  extends BaseService<CarCustomer>{




}
