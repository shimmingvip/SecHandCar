package com.neusoft.dao;

import com.neusoft.base.dao.BaseDao;
import com.neusoft.model.CarCustomer;

public interface CarCustomerDao extends BaseDao<CarCustomer>{
    



}

